<?php include("mysqlconnection.php") ?>
<html>
<head>
	<title>Homepage</title>
	<link rel="stylesheet" type="text/css" href="home.css">
</head>
<body>
	<div class="boxbar">
			<address>
				<a href="mailto:bhargavireddykakireddy123@gmail.com">bhargavireddykakireddy123@gmail.com</a>
			</address>
   			<!--<img src="fb.png">
   			<img src="tw.png">-->
   			<img src="gl.png"></a>
   			<img src="rguktb1.jpg">
		</div>
	<div class="menu-bar">
	<ul>
		<!--<li class="active"><a href="#"><i class="fas fa-home"></i>Home</a></li>-->
		<li><a href="#">Home</a></li>
		<li><a href="about.html">About us</a><i class="fa fa-user"></i>
			<!--<div class="sub-menu1">
				<ul>
					<li><a href="#">Mission</a></li>
					<li><a href="#">Vision</a></li>
					<li><a href="#">Team</a></li>
				</ul>
			</div>-->
		</li>
		<!--<li><a href="login.html" target="_blank">Login/Register</a></li>-->
		<li><a href="#">Login/Register</a>
		<div class="sub-menu1">
				<ul>
					<li><a href="<?PHP echo SITEURL;?>student/login.php" target="_blank">Student</a></li>
					<li><a href="<?PHP echo SITEURL;?>student/login.php" target="_blank">Faculty</a></li>
				</ul>
		</div></li>
		<li><a href="<?PHP echo SITEURL;?>student/g1.php" target="_blank">Gallery</a></li>
		<li><a href="<?PHP echo SITEURL;?>student/contact.php" target="_blank">Contact</a></li>
		<li><a href="<?PHP echo SITEURL;?>student/logout.php" target="_blank">Logout</a></li>
	</ul>
	</div>
</body>
</html>
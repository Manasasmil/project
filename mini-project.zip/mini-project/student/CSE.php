<?php include('mysqlconnection.php');?>
<?php if(isset($_GET['department_name']))
        {
            $department_name=$_GET['department_name'];
        }
		$_SESSION['branch']=$department_name;
?>
    
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/cse.css">
</head>
<body>
		
							<h1 style="margin-right: 100px">YEARS</h1>
							<div class="row">
	
		<?php
					$sql="SELECT * from year where year_department_name='$department_name'";
					
					$res=mysqli_query($conn,$sql) or die(mysqli_error());
					if($res==TRUE)
					{
						
						$count=mysqli_num_rows($res);
						if($count>0)
						{
							$c=0;
						while($rows=mysqli_fetch_assoc($res))
						{
							$c++;
							
							$year_number=$rows['year_number'];
							$year_department_name=$rows['year_department_name'];
							$year_image=$rows['year_image'];
							?>
							
						
							<?php 
								if($c==3)
								{
								$c=0;
								?>
								</div>
								<div class="row">
									<?php
			
							}
							?>
							<div class="column" style="margin-left: 25px;">
							<a href="<?PHP echo SITEURL;?>student/CSE-E3.php?year_number=<?php echo $year_number;?>"target="_blank"><p><?php echo $year_number?></p></a>
							</div>	
							<?php
						}
					}
					}
					?>
					<body class="image" background="<?php echo SITEURL ; ?>images/years/<?php echo $year_image; ?>" style="background-repeat: no-repeat; background-size: 100%"></body>
					
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title>CIVIL</title>
	<link rel="stylesheet" type="text/css" href="css/civil.css">
</head>
<body>
	<body class="image" background="img/civil1.jpg" style="background-repeat: no-repeat; background-size: 100%"></body>
		<h1 style="margin-right: 100px">YEARS</h1>
	<div class="row">
		<div class="column" style="margin-left: 25px;">
			<a href="CIVIL-E1.html" target="_blank"><p>E1</p></a>
		</div>
		<div class="column" style="margin-left: 850px;">
			<a href="CIVIL-E2.html" target="_blank"><p>E2</p></a>
		</div>
	</div>
	<div class="row">
		<div class="column" style="margin-left: 25px;">
			<a href="CIVIL-E3.html" target="_blank"><p>E3</p></a>
		</div>
		<div class="column" style="margin-left: 850px;">
			<a href="CIVIL-E4.html" target="_blank"><p>E4</p></a>
		</div>
	</div>
</body>
</html>
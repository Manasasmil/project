<!DOCTYPE html>
<html>
<head>
	<title>MME</title>
	<link rel="stylesheet" type="text/css" href="css/mme.css">
</head>
<body>
	<body class="image" background="img/mme1.jpg" style="background-repeat: no-repeat; background-size: 100%"></body>
		<h1 style="margin-right: 100px">YEARS</h1>
	<div class="row">
		<div class="column" style="margin-left: 25px;">
			<a href="E1.html" target="_blank"><p>E1</p></a>
		</div>
		<div class="column" style="margin-left: 850px;">
			<a href="E2.html" target="_blank"><p>E2</p></a>
		</div>
	</div>
	<div class="row">
		<div class="column" style="margin-left: 25px;">
			<a href="E3.html" target="_blank"><p>E3</p></a>
		</div>
		<div class="column" style="margin-left: 850px;">
			<a href="E4.html" target="_blank"><p>E4</p></a>
		</div>
	</div>
</body>
</html>
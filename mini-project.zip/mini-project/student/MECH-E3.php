<!DOCTYPE html>
<html>
<head>
	<title>MECH-E3</title>
	<link rel="stylesheet" type="text/css" href="css/mech-e3.css">
</head>
<body style="background-color: #f0ffff">
	<h1>COURSES</h1>
	<div class="row">
		<div class="column">
			<a href="DMM.html" target="_blank"><p>Design of Machine Members</p></a>
		</div>
		<div class="column">
			<a href="DM.html" target="_blank"><p>Dynamics of Machinery</p></a>
		</div>
		<div class="column">
			<a href="AT.html" target="_blank"><p>Applied Thermodynamics</p></a>
		</div>
		<div class="column">
			<a href="MEFA.html" target="_blank"><p>Managerial Economics and Financial Analysis</p></a>
		</div>
		<div class="column">
			<a href="ES.html" target="_blank"><p>Environmental Science</p></a>
		</div>
		<div class="column">
			<a href="TOE.html" target="_blank"><p>Theory of Elasticity</p></a>
		</div>
		<div class="column">
			<a href="HT.html" target="_blank"><p>Heat Transfer</p></a>
		</div>
	</div>
</body>
</html>
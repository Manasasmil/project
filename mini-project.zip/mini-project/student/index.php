<html>
	<head>
		<title> e-learning-platform> </titile>
		<link rel="stylesheet" href="admin.css">
	</head>
	<body>
		<!.... menu starts.....>
		<div class=menu>
			<div class = wrapper>
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">Student</a></li>
					<li><a href="#">Faculty</a></li>
					<li><a href="#">Department</a></li>
					<li><a href="#">year</a></li>
					<li><a href="#">course</a></li>
				</ul>
			</div>
		</div>
		<!.......menu ends......>

		<!.......main starts......>
		<div class=main>
			<div class=wrapper>
				<strong>DASHBOARD</strong>
			</div>
		</div>
		<!.......main ends......>

		<!.......main starts......>
		<div class=footer>
			<div class=wrapper>
				<p class=text-center> @2021 all rights are reserved developed by <a href="#">Srujana</a></p>
			</div>
		</div>


		

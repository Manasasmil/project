<?php include('mysqlconnection.php');?>
<html>
<head>
	<title>CSE-E3</title>
	<link rel="stylesheet" type="text/css" href="css/cse-e3.css">
</head>
<body style="background-color: #fffaf0">
	<h1>Classes</h1>
	<?php if(isset($_GET['year_number']))
        {
            $year_number=$_GET['year_number'];
			$_SESSION['year']=$year_number;
        }
		

?>
<?php


?>
<?php if(isset($_SESSION['branch']))
{
      $class_department_name=$_SESSION['branch'];

}
?>

	<?php
		$sql="SELECT * from class where class_department_name='$class_department_name' and class_year_number='$year_number'";
					
		$res=mysqli_query($conn,$sql) or die(mysqli_error());
		if($res==TRUE)
		{
			$count=mysqli_num_rows($res);
			if($count>0)
			{
			while($rows=mysqli_fetch_assoc($res))
			{
					$class_name=$rows['class_name'];
				?>
				<div class="row">


				<div class="column">
						<a href="<?PHP echo SITEURL;?>student/MECH-E3.php?class_ame=<?php echo $class_name;?>" target="_blank"><p><?php echo $class_name ?></p></a>
				</div>
		
				</div>
				<?php
			}
		}
	}
	?>

</body>
</html>
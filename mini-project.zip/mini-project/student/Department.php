<?php include("mysqlconnection.php") ?>
<html>
<head>
	<meta charset="UTF-8">
	<title>Departments</title>
	<link rel="stylesheet" type="text/css" href="css/department.css">
</head>
<body>
	<body style="background-color: #BCCBC9">
	<div class="menu">
		<div class="search-form">
			<input type="text" placeholder="search">
			<button>Search</button>
			<div class="autocom-box">
					<li>Artificial Intelligence</li>
					<li>Computer Networks</li>
					<li>Information Security</li>
					<li>Data Analytics</li>
					<li>Data Base Management System</li>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="js/suggestions.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
	<h1>Departments</h1>
	<div class="row">
	<?php
		$sql="SELECT * from department";
					
		$res=mysqli_query($conn,$sql) or die(mysqli_error());
		if($res==TRUE)
		{
			$count=mysqli_num_rows($res);
			if($count>0)
			{
				$c=0;
			while($rows=mysqli_fetch_assoc($res))
			{
				$c++;
				if($c==4)
				{
					$c=1;
					?>
					</div>
					<div class="row">
						<?php

				}
				
				$department_name=$rows['department_name'];
				$department_image=$rows['department_image'];
			
				?>	
		
			
		

		<div class="column">
			<a href="<?PHP echo SITEURL;?>student/CSE.php?department_name=<?php echo $department_name;?>" target="_blank"><img src="<?php echo SITEURL ; ?>images/departments/<?php echo $department_image; ?>" height="400px" width="400px">
			<figcaption class="fig"><?php echo $department_name;?></figcaption></a>
		</div>
		   <?php
			}
		   }
		}
		?>
	   
		
	</div>
</body>
</html>
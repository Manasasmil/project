<!DOCTYPE html>
<html>
<head>
	<title>CIVIL-E3</title>
	<link rel="stylesheet" type="text/css" href="css/civil-e3.css">
</head>
<body style="background-color: #f5fffa">
	<h1>COURSES</h1>
	<div class="row">
		<div class="column">
			<a href="SM.html" target="_blank"><p>Soil Mechanics</p></a>
		</div>
		<div class="column">
			<a href="HTE.html" target="_blank"><p>Highway and Traffic Engineering</p></a>
		</div>
		<div class="column">
			<a href="EC.html" target="_blank"><p>Estimation and Costing</p></a>
		</div>
		<div class="column">
			<a href="DSS.html" target="_blank"><p>Design of Steel Structures</p></a>
		</div>
		<div class="column">
			<a href="SA2.html" target="_blank"><p>Structural Analytics-II</p></a>
		</div>
		<div class="column">
			<a href="WRE.html" target="_blank"><p>Water Resource Engineering</p></a>
		</div>
		<div class="column">
			<a href="RAE.html" target="_blank"><p>Railway and Airport Engineering</p></a>
		</div>
		<div class="column">
			<a href="FE.html" target="_blank"><p>Foundation Engineering</p></a>
		</div>
	</div>
</body>
</html>
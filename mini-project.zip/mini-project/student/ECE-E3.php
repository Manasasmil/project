<!DOCTYPE html>
<html>
<head>
	<title>ECE-E3</title>
	<link rel="stylesheet" type="text/css" href="css/ece-e3.css">
</head>
<body style="background-color: #f8f8ff">
	<h1>COURSES</h1>
	<div class="row">
		<div class="column">
			<a href="DSP.html" target="_blank"><p>Digital Signal Processing</p></a>
		</div>
		<div class="column">
			<a href="CA.html" target="_blank"><p>Computer Architecture</p></a>
		</div>
		<div class="column">
			<a href="ADC.html" target="_blank"><p>Analog and Digital Communications</p></a>
		</div>
		<div class="column">
			<a href="NM.html" target="_blank"><p>Numerical Methods</p></a>
		</div>
		<div class="column">
			<a href="DSD.html" target="_blank"><p>Digital System Design</p></a>
		</div>
		<div class="column">
			<a href="MSI.html" target="_blank"><p>Micro-Controllers and Interfacing</p></a>
		</div>
	</div>
</body>
</html>
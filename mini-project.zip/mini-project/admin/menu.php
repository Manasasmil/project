
<?php
	 include('mysqlconnection.php');
	 include('logoutcheck.php');
?>
<html>
	<head>

		<link rel="stylesheet" href="admin.css">
	</head>
	<body>
		<!.... menu starts.....>
		<div class=menu>
			<div class = wrapper>
				<ul>
					<li><a href="home.php">Home</a></li>
					<li><a href="admin.php">admin</a></li>
					<li><a href="student.php">Student</a></li>
					<li><a href="faculty.php">Faculty</a></li>
					<li><a href="department.php">Department</a></li>
					<li><a href="year.php">Year</a></li>
					<li><a href="class.php">Class</a></li>
					<li><a href="course.php">Course</a></li>
					<li><a href="logout.php">logout</a></li>
				</ul>
			</div>
		</div>
		<!.......menu ends......>
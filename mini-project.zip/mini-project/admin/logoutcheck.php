<?php
if(!isset($_SESSION['user']))
{
    $_SESSION['no-login-messege']="please login";
    header('location:'.SITEURL.'admin/login.php');
}
?>
<?php include('menu.php');?>

		<!.......main starts......>
		<div class=main>
			<div class=wrapper>
				<strong>Dashboard</strong>
			</div>
		</div>
		<!.......main ends......>

		<!.......main starts......>
		<?php include('footer.php');?>
	

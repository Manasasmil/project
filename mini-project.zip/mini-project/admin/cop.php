<?php include('menu.php');?>
		<!.......main starts......>
		<div class=main>
			<div class=wrapper>
				<!......to add admin...>
				<a href="add_admin.php" class='btn-primary'>Add Admin</a>
				<table class=tbl-full>
					<tr>
						<th>s.no</th>
						<th>Admin_id</th>                   
						<th>Admin_name</th>
						<th>Actions</th>
				    </tr>

				    <tr>
				    	<td>1.</td>
				    	<td>RTCS00123</td>
				    	<td>Shaganti Mnasa</td>
				    	<td>
						<a href="#" class="btn-secondary">update admin</a>
						<a href="deleteadmin.php" class="btn-teritory">delete admin</a>
				    	</td>
				    </tr>
				    <tr>
				    	<td>1.</td>
				    	<td>RTCS00123</td>
				    	<td>Shaganti Mnasa</td>
				    	<td>
						<a href="#" class="btn-secondary">update admin</a>
						<a href="#" class="btn-teritory">delete admin</a>
				    	</td>
				    </tr>
				    <tr>
				    	<td>1.</td>
				    	<td>RTCS00123</td>
				    	<td>Shaganti Mnasa</td>
				    	<td>
				    	<a href="#" class="btn-secondary">update admin</a>
						<a href="#" class="btn-teritory">delete admin</a>
				    		
				    	</td>
				    </tr>

				    
				    	
				</table>
			</div>
		</div>
		<!.......main ends......>

		<!.......footer starts starts......>
		
		<!.......footer starts starts......>
		<?php include('footer.php');?>
	</body>
</html>


		

		<div class=footer>
			<div class=wrapper>
				<p class=text-center> @2021 all rights are reserved, developed by <a href="#">Srujana</a></p>
			</div>
		</div>
	<body>
</html>

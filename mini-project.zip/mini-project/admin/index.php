<?php include('menu.php');?>

		<!.......main starts......>
		<div class=main>
			<div class=wrapper>
				<table>
					<tr>
						<th>department_name</th>
				    </tr>
				</table>
			</div>
		</div>
		<!.......main ends......>

		<!.......footer starts starts......>
		
		<!.......footer starts starts......>
		<?php include('footer.php');?>



		
